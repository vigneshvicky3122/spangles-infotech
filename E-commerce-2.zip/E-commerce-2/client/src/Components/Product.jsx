import axios from "axios";
import React, { useEffect, useState } from "react";
import { URL } from "../App";
import { Link } from "react-router-dom";
function Product() {
  const [ProductData, setProductData] = useState([]);
  const [CartData, setCartData] = useState({});
  useEffect(() => {
    getData();
  }, []);
  async function getData() {
    try {
      const response = await axios.get(`${URL}/product/get-data`);
      if (response.data.status === 200) {
        setProductData(response.data.productData);
      }
    } catch (error) {
      console.log(error);
    }
  }
  const handleChange = (e) => {
    setCartData({ ...CartData, [e.target.name]: e.target.value });
  };
  async function handleSubmit(id) {}

  async function addToCart(id) {
    const Data = {
      name: ProductData[0].name,
      image: ProductData[0].images[0],
      category: ProductData[0].category,
      price: ProductData[0].price,
      CartData: CartData,
    };
    try {
      const response = await axios.post(
        `${URL}/product/add-to-cart/${id}`,
        Data
      );
      if (response.data.status === 200) {
        console.log(response.data.message);
      }
    } catch (error) {
      console.log(error);
    }
  }
  async function AddToWishlist(id) {
    const update = [...ProductData];
    update[0].wishlist = true;
    setProductData(update);
    try {
      const response = await axios.put(
        `${URL}/product/add-to-wishlist/${id}`,
        {}
      );
      if (response.data.status === 200) {
        console.log(response.data.message);
      }
    } catch (error) {
      console.log(error);
    }
  }
  async function RemoveFromWishlist(id) {
    const update = [...ProductData];
    update[0].wishlist = false;
    setProductData(update);
    try {
      const response = await axios.put(
        `${URL}/product/remove-from-wishlist/${id}`,
        {}
      );
      if (response.data.status === 200) {
        console.log(response.data.message);
      }
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <React.Fragment>
      <section className="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
        {ProductData &&
          ProductData.map((product, index) => (
            <div
              key={index}
              className="container d-flex flex-row justify-content-between gap-5 m-5"
            >
              <div className="w-50 d-flex flex-row gap-5">
                <div className="d-flex flex-row align-item-center gap-3">
                  <div className="w-25 d-flex flex-column justify-content-between gap-2">
                    {product.images.map((image, idx) => (
                      <img key={idx} src={image} alt="" width={100} />
                    ))}
                  </div>
                  <div id="carouselExample" className="carousel slide">
                    <div className="carousel-inner">
                      {product.images.map((image, idx) => (
                        <div
                          key={idx}
                          className={`carousel-item ${
                            idx === 0 ? "active" : ""
                          }`}
                        >
                          <img
                            src={image}
                            className="d-block w-100"
                            alt="..."
                          />
                        </div>
                      ))}
                    </div>
                    <button
                      className="carousel-control-prev"
                      type="button"
                      data-bs-target="#carouselExample"
                      data-bs-slide="prev"
                    >
                      <span
                        className="carousel-control-prev-icon"
                        aria-hidden="true"
                      ></span>
                      <span className="visually-hidden">Previous</span>
                    </button>
                    <button
                      className="carousel-control-next"
                      type="button"
                      data-bs-target="#carouselExample"
                      data-bs-slide="next"
                    >
                      <span
                        className="carousel-control-next-icon"
                        aria-hidden="true"
                      ></span>
                      <span className="visually-hidden">Next</span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="w-50 d-flex flex-column m-3">
                <div className="d-flex flex-row justify-content-between align-items-center">
                  <h5 className="">{product.name}</h5>
                  {!product.wishlist ? (
                    <i
                      className="bi bi-heart bg-light px-2 py-1 rounded-5 hover-cursor-pointer"
                      onClick={() => AddToWishlist(product._id)}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-heart-fill px-2 py-1 rounded-5 text-danger hover-cursor-pointer"
                      onClick={() => RemoveFromWishlist(product._id)}
                    ></i>
                  )}
                </div>
                <p className="text-secondary fw-semibold fs-6">
                  {product.category}
                </p>
                <div className="d-flex flex-column">
                  <div className="d-flex flex-column">
                    <div className="d-flex flex-row align-item-center gap-2">
                      <p className="fs-6 fw-bold">&#8377;{product.price}</p>
                      <s className="fs-6 text-secondary">
                        &#8377;{product.price}
                      </s>
                      <p className="fs-6 fw-semibold text-success">(50% off)</p>
                    </div>
                    <p className="text-secondary fw-semibold">
                      Inclusive of All Taxes + Free Shipping
                    </p>
                  </div>
                  <div className="d-flex flex-row gap-3">
                    <div className="d-flex flex-row">
                      <i className="bi bi-star-fill text-warning"></i>
                      <i className="bi bi-star-fill text-warning"></i>
                      <i className="bi bi-star-fill text-warning"></i>
                      <i className="bi bi-star-fill text-warning"></i>
                      <i className="bi bi-star-fill text-warning"></i>
                    </div>
                    <p>
                      <span className="fw-bold">
                        {product.ratings.rating.toFixed(1)}
                      </span>
                      <span className="text-secondary">
                        ({product.ratings.count} Ratings & Reviews)
                      </span>
                    </p>
                  </div>
                  <div className="d-flex flex-row align-item-center gap-2">
                    <i className="bi bi-tag-fill text-danger fs-5"></i>
                    <p className="fw-bold fs-6">
                      Extra &#8377;100 OFF on &#8377;999 (Code:BEYOUNG100)
                    </p>
                  </div>
                  <div className="d-flex flex-row gap-3 my-3">
                    <div className="w-25 d-flex flex-column gap-3">
                      {[1, 2, 3, 4].map((c, idx) => (
                        <div className="d-flex flex-column" key={idx}>
                          <label htmlFor={`Color ${c}`} className="fw-semibold">
                            {`Color ${c}`}{" "}
                            <span className="text-danger">*</span>
                          </label>
                          <select
                            id={`Color ${c}`}
                            name={`Color ${c}`}
                            required={true}
                            defaultValue={"Black"}
                            className="form-select"
                            aria-label="Default select example"
                            onChange={handleChange}
                          >
                            <option>select</option>
                            {product.colors.map((color, i) => (
                              <option value={color} key={i}>
                                {color}
                              </option>
                            ))}
                          </select>
                        </div>
                      ))}
                    </div>
                    <div className="w-25 d-flex flex-column gap-3">
                      {[1, 2, 3, 4].map((c, idx) => (
                        <div className="d-flex flex-column" key={idx}>
                          <label htmlFor={`Size ${c}`} className="fw-semibold">
                            {`Size ${c}`} <span className="text-danger">*</span>
                          </label>
                          <select
                            id={`Size ${c}`}
                            name={`Size ${c}`}
                            required={true}
                            defaultValue={"M"}
                            className="form-select"
                            aria-label="Default select example"
                            onChange={handleChange}
                          >
                            <option>select</option>
                            {product.size.map((size, i) => (
                              <option value={size} key={i}>
                                {size}
                              </option>
                            ))}
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="d-flex flex-row justify-content-between my-3">
                    <div className="w-25 d-flex flex-row">
                      <label htmlFor="Qty" className="fw-semibold">
                        Qty:
                      </label>
                      &nbsp;
                      <select
                        id="Qty"
                        name="Qty"
                        className="form-select"
                        aria-label="Default select example"
                        onChange={handleChange}
                      >
                        <option>select</option>
                        {[1, 2, 3, 4, 5].map((qty, i) => (
                          <option value={qty} key={i}>
                            {qty}
                          </option>
                        ))}
                      </select>
                    </div>
                    <Link
                      to="/"
                      className="text-primary fw-bold text-decoration-none"
                    >
                      SIZE CHART
                    </Link>
                  </div>
                </div>
                <div className="d-flex flex-column gap-3">
                  <button className="w-100 btn btn-light" type="button">
                    <i className="bi bi-gift-fill fw-bold"></i> OFFERS FOR YOU
                  </button>
                  <div className="d-flex flex-row gap-3">
                    <button
                      className="w-100 btn btn-primary"
                      type="button"
                      onClick={() => addToCart(product._id)}
                    >
                      <i className="bi bi-cart3"></i> ADD TO CART
                    </button>
                    <button
                      className="w-100 btn btn-warning"
                      type="button"
                      onClick={() => handleSubmit(product._id)}
                    >
                      <i className="bi bi-arrow-right"></i> BUY NOW
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
      </section>
    </React.Fragment>
  );
}

export default Product;
