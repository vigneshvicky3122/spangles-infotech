import React from "react";
import "./App.css";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Product from "./Components/Product";
export const URL = import.meta.env.VITE_BACKEND_API;
function App() {
  return (
    <React.Fragment>
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<Navigate to="/product" />} />
          <Route path="/product" element={<Product />} />
        </Routes>
      </BrowserRouter>
    </React.Fragment>
  );
}

export default App;
