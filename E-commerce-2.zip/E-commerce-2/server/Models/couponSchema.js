const { Schema, model } = require("mongoose");
const CouponSchema = new Schema({
  couponCode: String,
  discountAmount: Number,
});
let CouponModal = model(process.env.DB_COLLECTION_FOUR, CouponSchema);
module.exports = CouponModal;
